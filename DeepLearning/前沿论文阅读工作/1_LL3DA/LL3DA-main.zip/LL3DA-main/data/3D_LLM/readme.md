## The ScanNet part of 3D_LLM dataset

The data are located at [here](./). We have also shared our pre-processing scripts [here](./pre-process-3D-LLM.py).