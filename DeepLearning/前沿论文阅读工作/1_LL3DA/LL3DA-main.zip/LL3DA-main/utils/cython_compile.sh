#!/bin/bash
# Copyright (c) Facebook, Inc. and its affiliates.
python cython_compile.py build_ext --inplace
