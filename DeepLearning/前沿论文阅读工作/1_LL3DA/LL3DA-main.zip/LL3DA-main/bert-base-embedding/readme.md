## Download the pre-trained BERT embeddings

Download the pre-processed BERT embedding weights from [huggingface](https://huggingface.co/CH3COOK/bert-base-embedding/tree/main) and store them under the [`./bert-base-embedding`]() folder. The weights are **the same** from the official BERT model, we just modified the names of certain parameters.